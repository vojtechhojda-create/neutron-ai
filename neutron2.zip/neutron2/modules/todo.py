import json
from pathlib import Path

NAME = "Úkoly"
DESCRIPTION = "todo_add, todo_done, todo_list + /todo; otevřené úkoly vidí AI v promptu"

FILE = Path(__file__).resolve().parent.parent / "todo.json"


def _load():
    try:
        return json.loads(FILE.read_text(encoding="utf-8"))
    except Exception:
        return []


def _save(items):
    FILE.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")


def _fmt(items):
    return "\n".join(f"{i}. [{'x' if t['done'] else ' '}] {t['text']}" for i, t in enumerate(items, 1)) or "(žádné úkoly)"


def _add(app, arg, body):
    items = _load()
    items.append({"text": (arg or body).strip(), "done": False})
    _save(items)
    app.refresh_system()
    return f"Přidáno jako úkol č. {len(items)}"


def _done(app, arg, body):
    items = _load()
    i = int(arg) - 1
    items[i]["done"] = True
    _save(items)
    app.refresh_system()
    return f"Hotovo: {items[i]['text']}"


def _hook(app):
    open_ = [t["text"] for t in _load() if not t["done"]]
    return ("Otevřené úkoly uživatele:\n" + "\n".join("- " + t for t in open_[:10])) if open_ else None


def _cmd(app, arg):
    sub, _, rest = arg.partition(" ")
    items = _load()
    th = app.theme
    if sub == "add" and rest:
        _add(app, rest, "")
    elif sub == "done" and rest.strip().isdigit():
        try:
            _done(app, rest.strip(), "")
        except Exception:
            app.say("Takový úkol neexistuje.", "err")
            return
    elif sub == "clear":
        _save([t for t in items if not t["done"]])
        app.refresh_system()
    items = _load()
    if not items:
        app.say("Žádné úkoly. /todo add text")
    for i, t in enumerate(items, 1):
        mark = f"{th.ok}☑" if t["done"] else f"{th.b}☐"
        print(f"  {mark}\033[0m {th.dim if t['done'] else ''}{i}. {t['text']}\033[0m")
    app.say("/todo add text · /todo done N · /todo clear (smaže hotové)")


def register(app):
    app.add_tool("todo_add", _add, "přidá úkol do seznamu (arg = text úkolu)")
    app.add_tool("todo_done", _done, "označí úkol jako hotový (arg = číslo úkolu)")
    app.add_tool("todo_list", lambda a, arg, b: _fmt(_load()), "vypíše všechny úkoly")
    app.add_prompt_hook(_hook)
    app.add_command("todo", _cmd, "seznam úkolů")
