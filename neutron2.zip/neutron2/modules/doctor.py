"""Diagnostika: ověří, že Neutron na tomto počítači opravdu funguje, a poradí, co opravit."""
import json
import os
import platform
import shutil
import sys
import time
from datetime import datetime

try:
    import msvcrt
except ImportError:
    msvcrt = None

NAME = "Diagnostika"
DESCRIPTION = "/doctor ověří model, GPU, JSON režim, terminál a uloží zprávu; /log ukáže poslední chyby"

OK, WARN, FAIL = "ok", "warn", "fail"


def c_python(app):
    v = platform.python_version()
    return (OK if sys.version_info >= (3, 9) else FAIL, f"Python {v}", platform.platform(), "Potřebuješ Python 3.9 nebo novější.")


def c_llama(app):
    try:
        import llama_cpp
    except ImportError:
        return (FAIL, "llama-cpp-python", "není nainstalovaný",
                "pip install llama-cpp-python --prefer-binary --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu")
    ver = getattr(llama_cpp, "__version__", "?")
    try:
        gpu = bool(llama_cpp.llama_supports_gpu_offload())
    except Exception:
        gpu = False
    return (OK, f"llama-cpp-python {ver}", f"GPU offload: {'ano' if gpu else 'ne (běží na CPU)'}",
            "")


def c_terminal(app):
    cols = shutil.get_terminal_size((100, 30)).columns
    modern = bool(os.environ.get("WT_SESSION") or os.environ.get("COLORTERM") in ("truecolor", "24bit")
                  or os.environ.get("TERM_PROGRAM"))
    if os.name == "nt" and not modern:
        return (WARN, "Terminál", f"{cols} sloupců, barvy nejspíš omezené",
                "Použij Windows Terminal (obchod Microsoft Store) – barvy a přechody budou správně.")
    if cols < 80:
        return (WARN, "Terminál", f"jen {cols} sloupců", "Zvětši okno aspoň na 80 sloupců.")
    return (OK, "Terminál", f"{cols} sloupců, barvy v pořádku", "")


def c_keys(app):
    if msvcrt:
        return (OK, "Klávesa End / Esc", "funguje (Windows)", "")
    return (WARN, "Klávesa End / Esc", "mimo Windows nedostupná", "Zastavení odpovědi řeš přes Ctrl+C.")


def c_ptk(app):
    try:
        import prompt_toolkit
        return (OK, "prompt_toolkit", f"verze {prompt_toolkit.__version__} – našeptávač příkazů a lišta", "")
    except ImportError:
        return (WARN, "prompt_toolkit", "chybí – vstup je jednodušší, bez našeptávače", "pip install prompt_toolkit")


def c_ram(app):
    tot = free = None
    try:
        if os.name == "nt":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            tot, free = m.ullTotalPhys, m.ullAvailPhys
        else:
            info = {}
            for line in open("/proc/meminfo"):
                k, v = line.split(":")
                info[k] = int(v.split()[0]) * 1024
            tot, free = info["MemTotal"], info["MemAvailable"]
    except Exception:
        return (WARN, "RAM", "nepodařilo se zjistit", "")
    detail = f"{free / 1e9:.1f} GB volných z {tot / 1e9:.1f} GB"
    if app.model_path and app.model_path.exists():
        size = app.model_path.stat().st_size
        if size > 0.8 * tot:
            return (FAIL, "RAM", f"{detail}; model má {size / 1e9:.1f} GB", "Model se do paměti nevejde – vyber menší (/models).")
        if size > 0.6 * free:
            return (WARN, "RAM", f"{detail}; model má {size / 1e9:.1f} GB", "Málo volné paměti, zavři jiné aplikace nebo vyber menší model.")
    return (OK, "RAM", detail, "")


def c_disk(app):
    try:
        test = app.base / ".neutron_write_test"
        test.write_text("x")
        test.unlink()
        free = shutil.disk_usage(app.base).free / 1e9
        return (OK if free > 2 else WARN, "Zápis na disk", f"v pořádku, volné místo {free:.1f} GB",
                "" if free > 2 else "Málo místa na disku pro stahování modelů.")
    except Exception as e:
        return (FAIL, "Zápis na disk", str(e)[:80], "Spusť Neutron ze složky, kam smíš zapisovat.")


def c_modules(app):
    bad = [m for m in app.modules if m["error"]]
    if bad:
        return (WARN, "Moduly", "; ".join(f"{m['id']}: {m['error'][:50]}" for m in bad), "Oprav nebo vypni vadný modul v /nastaveni → Moduly.")
    return (OK, "Moduly", f"{sum(1 for m in app.modules if m['ok'])} načteno, {len(app.tools)} nástrojů", "")


def c_generation(app):
    if not app.llm:
        return (FAIL, "Model", "není načtený", "Vyber model přes /models.")
    t0, first, n = time.time(), None, 0
    try:
        for ch in app.llm.create_chat_completion(messages=[{"role": "user", "content": "Řekni jedno slovo: ahoj"}],
                                                 max_tokens=16, temperature=0.0, stream=True):
            if first is None:
                first = time.time()
            if ch["choices"][0]["delta"].get("content"):
                n += 1
    except Exception as e:
        return (FAIL, "Generování", str(e)[:100], "Podrobnosti: /log")
    if not n:
        return (FAIL, "Generování", "model nevrátil žádný text", "Zkus jiný model nebo aktualizuj llama-cpp-python.")
    rate = n / max(time.time() - first, 1e-6)
    detail = f"{app.model_path.name}: {n} tokenů, {rate:.1f} tok/s, první token za {first - t0:.1f} s"
    if rate < 3:
        return (WARN, "Generování", detail, "Pomalé. Zkus menší model, GPU (/set n_gpu_layers -1) nebo menší kontext.")
    return (OK, "Generování", detail, "")


def c_json(app):
    if not app.llm:
        return (WARN, "JSON režim /goal", "model není načtený", "")
    schema = {"type": "object", "properties": {"action": {"type": "string", "enum": ["alfa", "beta"]}}, "required": ["action"]}
    try:
        r = app.llm.create_chat_completion(messages=[{"role": "user", "content": "Vyber alfa."}], max_tokens=24,
                                           temperature=0.0, response_format={"type": "json_object", "schema": schema})
        obj = json.loads(r["choices"][0]["message"]["content"])
        if obj.get("action") in ("alfa", "beta"):
            return (OK, "JSON režim /goal", "omezený výstup funguje – agent bude spolehlivý", "")
        return (WARN, "JSON režim /goal", "výstup neodpovídá schématu", "Použij /set goal_mode tags")
    except Exception as e:
        return (WARN, "JSON režim /goal", f"nefunguje ({str(e)[:70]})", "Použij /set goal_mode tags nebo aktualizuj llama-cpp-python.")


CHECKS = [c_python, c_llama, c_terminal, c_keys, c_ptk, c_ram, c_disk, c_modules, c_generation, c_json]


def _doctor(app, arg):
    T = app.theme
    marks = {OK: (T.ok, "✔"), WARN: (T.b, "⚠"), FAIL: (T.err, "✖")}
    results, plain = [], [f"Neutron diagnostika {datetime.now():%Y-%m-%d %H:%M:%S}"]
    print(f"\n  {T.a}\033[1m◆ Diagnostika\033[0m\n")
    for fn in CHECKS:
        sp = app.Spinner("kontroluji") if fn in (c_generation, c_json) else None
        if sp:
            sp.start()
        try:
            st, title, detail, hint = fn(app)
        except Exception as e:
            st, title, detail, hint = FAIL, fn.__name__, f"kontrola selhala: {e}", ""
        finally:
            if sp:
                sp.stop()
        col, mk = marks[st]
        print(f"  {col}{mk}\033[0m {title}  {T.dim}{detail}\033[0m")
        if hint and st != OK:
            print(f"      {T.dim}→ {hint}\033[0m")
        plain.append(f"[{st.upper():4}] {title} – {detail}" + (f"\n        -> {hint}" if hint and st != OK else ""))
        results.append(st)
    fails, warns = results.count(FAIL), results.count(WARN)
    print()
    if fails:
        app.say(f"✖ {fails} problémů, {warns} varování – oprav je podle tipů výše.", "err")
    elif warns:
        app.say(f"⚠ Funguje, ale {warns} varování ke zvážení.", "dim")
    else:
        app.say("✔ Všechno v pořádku, Neutron je připravený naplno.", "ok")
    try:
        d = app.base / "logs"
        d.mkdir(exist_ok=True)
        (d / "doctor.txt").write_text("\n".join(plain) + "\n", encoding="utf-8")
        app.say("Zpráva uložena do logs/doctor.txt (pošli ji, když budeš chtít pomoc).")
    except Exception:
        pass


def _log(app, arg):
    f = app.base / "logs" / "neutron.log"
    if not f.exists() or not f.read_text(encoding="utf-8").strip():
        app.say("Log je prázdný – žádné chyby.", "ok")
        return
    lines = f.read_text(encoding="utf-8").splitlines()[-int(arg or 25):]
    for l in lines:
        print("  " + app.theme.dim + l[:140] + "\033[0m")


def register(app):
    app.add_command("doctor", _doctor, "diagnostika: ověří, že vše funguje, a poradí")
    app.add_command("log", _log, "ukáže posledních 25 řádků logu chyb (/log 60 = víc)")
