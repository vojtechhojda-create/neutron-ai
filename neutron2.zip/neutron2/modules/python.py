import subprocess
import sys
import tempfile
from pathlib import Path

NAME = "Python"
DESCRIPTION = "run_python: spustí Python kód z těla značky (s potvrzením)"


def _run(app, arg, body):
    code = body or arg
    with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False, encoding="utf-8") as f:
        f.write(code)
        path = f.name
    try:
        r = subprocess.run([sys.executable, path], cwd=app.workdir, capture_output=True, text=True,
                           timeout=30, encoding="utf-8", errors="replace")
        return (r.stdout + r.stderr).strip() or "(bez výstupu)"
    finally:
        Path(path).unlink(missing_ok=True)


def register(app):
    app.add_tool("run_python", _run, "spustí Python kód z těla značky a vrátí výstup (max 30 s)", dangerous=True)
