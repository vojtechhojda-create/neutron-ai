"""Okno nastavení – celoobrazovkový strom: ↑↓ pohyb, ← zabalit, → rozbalit/upravit, Enter upravit."""
import contextlib
import io
import json
import os
import re
import sys

try:
    import msvcrt
except ImportError:
    msvcrt = None

NAME = "Okno nastavení"
DESCRIPTION = "/nastaveni: strom nastavení v samostatném okně (↑ ↓ ← → Enter) s živým náhledem"

RST, BLD = "\033[0m", "\033[1m"
ANSI = re.compile(r"\033\[[0-9;]*m")
HEX = re.compile(r"#?[0-9a-fA-F]{6}")


def vlen(s):
    return len(ANSI.sub("", s))


# ───────────────────────── klávesy ─────────────────────────
def read_key():
    if msvcrt:
        k = msvcrt.getwch()
        if k in ("\x00", "\xe0"):
            return {"H": "up", "P": "down", "K": "left", "M": "right", "G": "home", "O": "end",
                    "I": "pgup", "Q": "pgdn", "S": "del"}.get(msvcrt.getwch(), "")
        if k == "\r":
            return "enter"
        if k == "\x1b":
            return "esc"
        if k == "\x03":
            raise KeyboardInterrupt
        return k
    import select
    import termios
    import tty
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        ch = os.read(fd, 1).decode(errors="ignore")
        if ch == "\x1b":
            if select.select([fd], [], [], 0.05)[0]:
                seq = os.read(fd, 8).decode(errors="ignore")
                return {"[A": "up", "[B": "down", "[C": "right", "[D": "left", "[H": "home", "[F": "end",
                        "OA": "up", "OB": "down", "OC": "right", "OD": "left", "[5~": "pgup", "[6~": "pgdn",
                        "[3~": "del"}.get(seq, "")
            return "esc"
        if ch in ("\r", "\n"):
            return "enter"
        if ch == "\x03":
            raise KeyboardInterrupt
        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


# ───────────────────────── model stromu ─────────────────────────
class Node:
    def __init__(self, label, typ="cat", **kw):
        self.label, self.typ = label, typ
        self.children, self.expanded = [], False
        self.key = self.desc = None
        self.reload = self.restart = self.style = self.sysref = False
        self.choices, self.lo, self.hi, self.step, self.fmt = [], None, None, 1, None
        self.get = self.set = self.fn = self.reset = None
        self.__dict__.update(kw)


def build(app):
    s = app.s

    def item(label, key, typ, desc="", **kw):
        return Node(label, typ, key=key, desc=desc, get=lambda: s.get(key),
                    set=lambda v: s.__setitem__(key, v), **kw)

    def ui(label, key, typ, desc="", **kw):
        return item(label, key, typ, desc, style=True, **kw)

    themes = list(app.themes())
    ALIGN = [("left", "vlevo"), ("center", "na střed"), ("right", "vpravo")]
    look = Node("Vzhled")
    look.children = [
        Node("Motiv", "choice", key="theme", style=True, desc="Barevný motiv celé aplikace. Vlastní motivy dej do složky themes/.",
             choices=[(t, t) for t in themes], get=lambda: s["theme"],
             set=lambda v: (s.__setitem__("theme", v), s.__setitem__("custom_colors", {}))),
        ui("Zarovnání textu", "ui_align", "choice", "Zarovnání odpovědí: vlevo / na střed / vpravo (seznamy, kód a tabulky zůstávají vlevo).",
           choices=ALIGN),
        ui("Šířka textu", "ui_width", "number", "Maximální šířka odpovědí ve sloupcích. 0 = automaticky podle okna.",
           lo=0, hi=140, step=5, fmt=lambda v: "auto" if not v else str(v)),
        ui("Pruh odpovědi", "ui_bar", "choice", "Znak svislého pruhu vlevo od odpovědi.",
           choices=[("▎", "▎  tenký"), ("┃", "┃  plný"), ("│", "│  čára"), ("▌", "▌  tlustý"), ("║", "║  dvojitý"),
                    ("¦", "¦  přerušovaný"), (" ", "žádný")]),
        ui("Odsazení zleva", "ui_margin", "number", "Počet mezer před každým řádkem.", lo=0, hi=12, step=1),
        ui("Znak promptu", "ui_prompt", "choice", "Symbol před řádkem, kam píšeš.",
           choices=[(c, c) for c in ("❯", "›", "»", ">", "$", "λ", "➜", "◆")]),
        ui("Pozice vstupního řádku", "ui_align_input", "choice", "Kde začíná řádek, do kterého píšeš: vlevo / na střed / vpravo.",
           choices=ALIGN),
        ui("Zvýraznění syntaxe kódu", "ui_highlight", "bool", "Barevné zvýraznění klíčových slov, řetězců a komentářů v blocích kódu."),
        ui("Animace čekání", "ui_spinner", "choice", "Vzhled spinneru při čekání na model.",
           choices=[("braille", "⠋⠙⠹  braille"), ("dots", "⣾⣽⣻  tečky"), ("line", "|/-\\  čára"), ("arrows", "←↖↑  šipky"),
                    ("pulse", "◐◓◑  puls"), ("blocks", "▖▘▝  bloky")]),
        ui("Oddělovač po odpovědi", "ui_divider", "choice", "Čára mezi výměnami: barevný přechod, jednoduchá, nebo žádná.",
           choices=[("gradient", "barevný přechod"), ("line", "jednoduchá čára"), ("none", "žádný")]),
        ui("Statistiky pod odpovědí", "ui_stats", "bool", "Řádek └ počet tokenů · tok/s · čas pod každou odpovědí."),
        ui("Jméno nad odpovědí", "ui_label", "bool", "Řádek ◆ Neutron nad každou odpovědí."),
        item("Zobrazovat myšlení", "show_think", "bool", "Ukazovat šedě <think> bloky u reasoning modelů."),
    ]

    align_keys = ["ui_align", "ui_align_header", "ui_align_label", "ui_align_panel", "ui_align_input"]

    def all_get():
        vals = {s.get(k) for k in align_keys}
        return vals.pop() if len(vals) == 1 else "různé"

    head = Node("Hlavička a zarovnání")
    head.children = [
        ui("Připnout hlavičku nahoře", "ui_pin", "bool",
           "Hlavička zůstane pořád nahoře a viditelná, chat se pod ní posouvá. Projeví se po zavření okna."),
        ui("Styl hlavičky", "ui_head_style", "choice",
           "Kompaktní = jeden řádek se stavem; logo = velké logo; plný = logo + rámeček. Příliš vysoká hlavička se sama zmenší.",
           choices=[("compact", "kompaktní"), ("logo", "logo"), ("full", "plný")]),
        ui("Logo", "ui_logo", "choice", "Velké ASCII logo, malé jednořádkové, nebo žádné.",
           choices=[("big", "velké"), ("small", "malé"), ("none", "žádné")]),
        item("Animace loga", "animate", "bool", "Logo se při startu odkrývá po řádcích."),
        ui("Zarovnání hlavičky", "ui_align_header", "choice", "Logo, tagline a info rámeček: vlevo / na střed / vpravo.", choices=ALIGN),
        ui("Zarovnání štítků a statistik", "ui_align_label", "choice",
           "Řádek se jménem asistenta a statistika pod odpovědí.", choices=ALIGN),
        ui("Zarovnání panelů a hlášek", "ui_align_panel", "choice",
           "Rámečky (Hotovo, Cíl, statistiky), výsledky nástrojů, hlášky a oddělovače.", choices=ALIGN),
        Node("Zarovnat vše", "choice", style=True, choices=ALIGN, get=all_get,
             set=lambda v: [s.__setitem__(k, v) for k in align_keys],
             reset=lambda: [s.__setitem__(k, "left") for k in align_keys],
             desc="Jedním krokem nastaví zarovnání textu, hlavičky, štítků, panelů i vstupního řádku."),
        ui("Info rámeček při startu", "ui_box", "bool", "Rámeček s modelem, složkou a výbavou pod logem."),
        ui("Tipy při startu", "ui_tips", "bool", "Náhodný tip pod logem."),
    ]

    colors = Node("Vlastní barvy")
    for key, label in [("accent", "Hlavní barva"), ("accent2", "Druhá barva (přechod)"), ("dim", "Ztlumený text"),
                       ("ok", "Úspěch"), ("err", "Chyba"), ("think", "Myšlení modelu"), ("code", "Kód")]:
        def g(k=key):
            d = app.theme.d
            return d.get(k) or d.get("accent2") or d["accent"]

        def st(v, k=key):
            s["custom_colors"] = {**s.get("custom_colors", {}), k: v}
        colors.children.append(Node(label, "color", key=key, style=True, get=g, set=st,
                                    desc="Přepíše barvu vybraného motivu. Zadej hex, např. #ff7a00. r = vrátit barvu motivu.",
                                    reset=lambda k=key: s.__setitem__(
                                        "custom_colors", {a: b for a, b in s.get("custom_colors", {}).items() if a != k})))
    colors.children.append(Node("Smazat vlastní barvy", "action", style=True, desc="Vrátí všechny barvy na hodnoty motivu.",
                                fn=lambda: s.__setitem__("custom_colors", {})))

    custom = Node("Vlastní")
    custom.children = [
        ui("Jméno asistenta", "ui_name", "text", "Jméno nad každou odpovědí a v logu (jiné než Neutron = malé logo)."),
        ui("Tagline", "ui_tagline", "text", "Text pod logem při startu."),
        item("Systémový prompt", "system_prompt", "text", "Základní instrukce modelu.", sysref=True),
        Node("Aliasy příkazů", "aliases", key="aliases", desc="Vlastní zkratky: g=/goal, tr=Přelož do angličtiny:. Enter přidá, zkratka= smaže.",
             get=lambda: s.get("aliases", {})),
        Node("Pracovní složka", "text", key="workdir", desc="Složka, ve které pracují nástroje (soubory, git, příkazy).",
             get=lambda: str(app.workdir), set=lambda v: app.commands["folder"][0](app, v)),
    ]
    custom.children.append(colors)

    perf = Node("Model a výkon")
    perf.children = [
        item("Teplota", "temperature", "number", "Kreativita odpovědí: nízká = přesné, vysoká = tvořivé.",
             lo=0.0, hi=2.0, step=0.05, fmt=lambda v: f"{float(v):.2f}"),
        item("Max. tokenů odpovědi", "max_tokens", "number", "Maximální délka jedné odpovědi.", lo=64, hi=8192, step=64),
        item("Kontext (n_ctx)", "n_ctx", "choice", "Kolik tokenů si model pamatuje. Vyžaduje znovunačtení modelu.", reload=True,
             choices=[(c, str(c)) for c in (2048, 4096, 8192, 16384, 32768)]),
        item("GPU vrstvy", "n_gpu_layers", "choice", "auto = zjistí GPU sám. Vyžaduje znovunačtení modelu.", reload=True,
             choices=[("auto", "auto"), (0, "0 – jen CPU"), (-1, "-1 – vše na GPU"), (16, "16 vrstev"), (32, "32 vrstev")]),
        item("Vlákna CPU", "n_threads", "number", "Počet vláken pro výpočet. Vyžaduje znovunačtení modelu.", reload=True,
             lo=1, hi=max(8, (os.cpu_count() or 4) * 2), step=1),
        item("Top-p", "top_p", "number", "Jádrové vzorkování: nižší = předvídatelnější výběr slov.",
             lo=0.1, hi=1.0, step=0.05, fmt=lambda v: f"{float(v):.2f}"),
        item("Top-k", "top_k", "number", "Kolik nejpravděpodobnějších slov se zvažuje (0 = vypnuto).", lo=0, hi=200, step=5),
        item("Penalizace opakování", "repeat_penalty", "number", "Vyšší = méně opakování, příliš vysoká zhoršuje text.",
             lo=1.0, hi=1.5, step=0.05, fmt=lambda v: f"{float(v):.2f}"),
        item("Seed", "seed", "number", "Pevné číslo = opakovatelné odpovědi. -1 = náhodně.",
             lo=-1, hi=99999, step=1, fmt=lambda v: "náhodný" if int(v) < 0 else str(v)),
        item("Automatické shrnování kontextu", "auto_compact", "bool",
             "Když se konverzace nevejde, starší část se shrne místo zahození."),
        item("Vypnout myšlení (Qwen3)", "no_think", "bool", "Přidá /no_think: Qwen3 odpovídá hned, bez dlouhého přemýšlení – chat je rychlejší. Pro těžké úlohy vypni.", sysref=True),
    ]

    agent = Node("Agent")
    agent.children = [
        item("Kroků pro /goal", "goal_steps", "number", "Kolik kroků smí agent udělat, než se zastaví.", lo=1, hi=100, step=1),
        item("Režim /goal", "goal_mode", "choice", "json = spolehlivé (omezený výstup), tags = starší režim se značkami.",
             choices=[("json", "json"), ("tags", "tags")]),
        item("Nástroje zapnuty", "tools", "bool", "Smí AI volat nástroje z modulů?", sysref=True),
        item("Potvrzování nástrojů", "approve", "choice", "Které nástroje se ptají na povolení: jen nebezpečné / všechny / žádný.",
             choices=[("danger", "jen nebezpečné"), ("all", "všechny"), ("none", "žádný (riskantní!)")]),
        item("Max. výstup nástroje", "tool_out_max", "number", "Kolik znaků výsledku nástroje vidí model.", lo=500, hi=20000, step=500),
        item("Pípnout po dlouhé odpovědi", "bell", "bool", "Zvukový signál, když odpověď trvala déle než limit níže."),
        item("Pípnout po (s)", "bell_min", "number", "Minimální doba odpovědi pro pípnutí.", lo=1, hi=300, step=5),
        item("Autosave konverzací", "autosave", "bool", "Po každé výměně uloží konverzaci (/load, /continue)."),
        Node("Auto-schvalovat nástroje", "bool", desc="Jen pro tuto relaci: nebudou se ptát na potvrzení nebezpečných akcí!",
             get=lambda: app.auto_approve, set=lambda v: setattr(app, "auto_approve", bool(v))),
    ]

    mods = Node("Moduly")
    for m in app.modules:
        def gm(mid=m["id"]):
            return mid not in s["disabled_modules"]

        def sm(v, mid=m["id"]):
            dis = [x for x in s["disabled_modules"] if x != mid]
            if not v:
                dis.append(mid)
            s["disabled_modules"] = dis
        mods.children.append(Node(m["name"], "bool", get=gm, set=sm, restart=True,
                                  desc=(m["desc"] or "Modul") + "  (změna se projeví po restartu)"))

    def reset_look():
        for k in ("theme", "ui_align", "ui_bar", "ui_margin", "ui_prompt", "ui_name", "ui_tagline", "ui_width", "ui_logo",
                  "animate", "show_think"):
            s[k] = app.defaults[k]
        s["custom_colors"] = {}

    def reset_all():
        for k, v in app.defaults.items():
            if k not in ("last_model", "workdir"):
                s[k] = type(v)(v) if isinstance(v, (dict, list)) else v
        s["disabled_modules"] = []

    def export_settings():
        f = app.base / "settings_export.json"
        f.write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")
        return f"✔ Uloženo do {f.name} (záloha / přenos na jiný počítač)."

    def import_settings():
        f = app.base / "settings_export.json"
        if not f.exists():
            return "Soubor settings_export.json neexistuje – nejdřív nastavení exportuj."
        s.update(json.loads(f.read_text(encoding="utf-8")))
        return "✔ Nastavení načteno z settings_export.json."

    manage = Node("Správa")
    manage.children = [
        Node("Exportovat nastavení", "action", fn=export_settings, desc="Uloží kopii všech nastavení do settings_export.json."),
        Node("Načíst nastavení z exportu", "action", style=True, sysref=True, reload=True, confirm=True, fn=import_settings,
             desc="Obnoví nastavení ze settings_export.json. Zeptá se na potvrzení."),
        Node("Obnovit výchozí vzhled", "action", style=True, fn=reset_look, desc="Motiv, zarovnání, pruh, jméno… zpět na výchozí."),
        Node("Obnovit vše na výchozí", "action", style=True, sysref=True, reload=True, confirm=True, fn=reset_all,
             desc="Všechna nastavení kromě modelu a pracovní složky. Zeptá se na potvrzení."),
    ]
    return [look, head, custom, perf, agent, mods, manage]


# ───────────────────────── okno ─────────────────────────
class UI:
    def __init__(self, app):
        self.app = app
        self.tree = build(app)
        self.tree[0].expanded = True
        self.cur = 1
        self.top = 0
        self.msg = ""
        self.reload = self.restart = False

    # --- pomocné ---
    def size(self):
        try:
            c, l = os.get_terminal_size()
        except OSError:
            c, l = 100, 30
        return c, l

    def visible(self):
        rows = []

        def walk(nodes, depth):
            for n in nodes:
                rows.append((n, depth))
                if n.typ == "cat" and n.expanded:
                    walk(n.children, depth + 1)
        walk(self.tree, 0)
        return rows

    def parent_of(self, node):
        def find(nodes, par):
            for n in nodes:
                if n is node:
                    return par
                if n.typ == "cat":
                    r = find(n.children, n)
                    if r is not None:
                        return r
            return None
        return find(self.tree, None)

    def value_str(self, n):
        T = self.app.theme
        v = n.get() if n.get else None
        if n.typ == "bool":
            return f"{T.ok}● zapnuto{RST}" if v else f"{T.dim}○ vypnuto{RST}"
        if n.typ == "choice":
            lab = next((l for val, l in n.choices if str(val) == str(v)), str(v))
            return f"{T.b}{lab}{RST} {T.dim}▾{RST}"
        if n.typ == "number":
            txt = n.fmt(v) if n.fmt else str(v)
            try:
                frac = (float(v) - n.lo) / (n.hi - n.lo)
            except Exception:
                frac = 0
            k = round(10 * max(0, min(1, frac)))
            return f"{T.a}{'▰' * k}{T.dim}{'▱' * (10 - k)}{RST} {txt}"
        if n.typ == "color":
            from_hex = str(v).lstrip("#")
            try:
                r, g, b = (int(from_hex[i:i + 2], 16) for i in (0, 2, 4))
                sw = f"\033[38;2;{r};{g};{b}m███{RST}"
            except Exception:
                sw = "???"
            return f"{sw} {T.dim}#{from_hex}{RST}"
        if n.typ == "text":
            t = str(v).replace("\n", " ")
            return f"{T.b}{t[:34] + '…' if len(t) > 34 else t}{RST}" if t else f"{T.dim}(prázdné){RST}"
        if n.typ == "aliases":
            return f"{T.b}{len(v)}{RST} {T.dim}" + (", ".join("/" + k for k in list(v)[:4]) or "žádné") + RST
        if n.typ == "action":
            return f"{T.dim}⏎ spustit{RST}"
        return ""

    def row(self, n, depth, selected, W):
        T = self.app.theme
        if n.typ == "cat":
            arrow = "▾" if n.expanded else "▸"
            txt = f" {T.a}{arrow}{RST} {BLD}{T.a}{n.label}{RST}" + (f" {T.dim}({len(n.children)}){RST}" if not n.expanded else "")
            txt = "  " * depth + txt
        else:
            label = n.label + (f" {T.b}⟳{RST}" if n.reload or n.restart else "")
            left = "  " * depth + "   " + ("  " if depth else "") + label
            pad = max(2, 40 + 2 * depth - vlen(left))
            txt = left + " " * pad + self.value_str(n)
        if selected:
            r, g, b = (int(c * 0.22) for c in T.c1)
            bg = f"\033[48;2;{r};{g};{b}m"
            txt = "❯" + txt[1:] if txt.startswith(" ") else txt
            txt = bg + txt.replace(RST, RST + bg) + " " * max(0, W - vlen(txt)) + RST
        return txt

    # --- vykreslení ---
    def preview(self, W, nlines):
        app = self.app
        buf = io.StringIO()
        sample = ("Ukázka odpovědi s **tučným** textem a `kódem`, zalomená podle nastavené šířky.\n\n"
                  "```python\nprint(\"ahoj\")  # komentář\n```")
        with contextlib.redirect_stdout(buf):
            lb = app.label()
            if lb:
                print(lb)
            app.render(sample, width=W - 14)
            app.footer("└ 42 tok · 18.3 tok/s · 2.3 s")
        return buf.getvalue().splitlines()[:nlines]

    def frame(self, body, hint, desc, title_extra=""):
        app = self.app
        T = app.theme
        cols, lines = self.size()
        W = max(60, min(cols - 2, 104))
        pv = 9 if lines >= 36 else (6 if lines >= 28 else 0)
        tree_h = max(5, lines - 6 - ((pv + 1) if pv else 0) - 1)
        out = []
        # nadpis s přechodem
        title = "◆ N A S T A V E N Í"
        g = "".join(("\033[38;2;%d;%d;%dm" % tuple(int(T.c1[k] + (T.c2[k] - T.c1[k]) * i / max(1, len(title) - 1)) for k in range(3))) + ch
                    for i, ch in enumerate(title)) + RST
        right = f"{T.dim}{title_extra or T.name}{RST}"
        out.append(" " + g + " " * max(1, W - vlen(g) - vlen(right) - 1) + right)
        out.append(" " + T.dim + "─" * W + RST)
        # tělo se scrollováním
        n = len(body)
        if self.cur >= self.top + tree_h:
            self.top = self.cur - tree_h + 1
        if self.cur < self.top:
            self.top = self.cur
        self.top = max(0, min(self.top, max(0, n - tree_h)))
        view = body[self.top:self.top + tree_h]
        for i in range(tree_h):
            if i < len(view):
                line = view[i]
                out.append(" " + line + " " * max(0, W - vlen(line)))
            else:
                out.append(" " * (W + 1))
        more = f"{T.dim}  ▲▼ {self.top + 1}–{min(n, self.top + tree_h)} z {n}{RST}" if n > tree_h else ""
        out.append(" " + T.dim + "─" * W + RST)
        d = desc or ""
        if self.msg:
            d = f"{T.ok}{self.msg}{RST}"
        else:
            d = f"{T.dim}{d}{RST}"
        d = d if vlen(d) <= W else d[:W + (len(d) - vlen(d)) - 1] + "…"
        out.append(" " + d + (" " * 2 if not more else "") + (more if vlen(d) + vlen(more) < W else ""))
        if pv:
            out.append(" " + T.dim + "─ náhled " + "─" * (W - 9) + RST)
            pl = self.preview(W, pv)
            for i in range(pv):
                out.append(" " + (pl[i] if i < len(pl) else ""))
        out.append(" " + T.dim + hint + RST)
        return "\033[H" + "\n".join(l + "\033[K" for l in out[:lines - 1]) + "\033[J"

    def draw(self):
        rows = self.visible()
        self.cur = max(0, min(self.cur, len(rows) - 1))
        W = max(60, min(self.size()[0] - 2, 104)) - 1
        body = [self.row(n, d, i == self.cur, W) for i, (n, d) in enumerate(rows)]
        node = rows[self.cur][0]
        hint = " ↑↓ pohyb · → rozbalit/upravit · ← zabalit · Enter upravit · +/- změnit hodnotu · r výchozí · Esc zavřít"
        sys.stdout.write(self.frame(body, hint, node.desc))
        sys.stdout.flush()

    def ask_text(self, prompt):
        T = self.app.theme
        _, lines = self.size()
        sys.stdout.write(f"\033[{lines};1H\033[K\033[?25h {T.a}{prompt}{RST} ")
        sys.stdout.flush()
        try:
            v = input()
        except (EOFError, KeyboardInterrupt):
            v = None
        sys.stdout.write("\033[?25l")
        return v

    def popup(self, node):
        app = self.app
        cur0 = node.get()
        idx = next((i for i, (v, _) in enumerate(node.choices) if str(v) == str(cur0)), 0)
        saved = dict(app.s)
        old_cur, old_top = self.cur, self.top
        while True:
            body = []
            for i, (v, lab) in enumerate(node.choices):
                body.append((f"{app.theme.a}❯ {RST}{BLD}{lab}{RST}") if i == idx else f"  {app.theme.dim}{lab}{RST}")
            self.cur = idx
            sys.stdout.write(self.frame(body, " ↑↓ výběr (náhled se mění hned) · Enter potvrdit · Esc zrušit", node.desc,
                                        title_extra=node.label))
            sys.stdout.flush()
            k = read_key()
            if k == "up":
                idx = (idx - 1) % len(node.choices)
            elif k == "down":
                idx = (idx + 1) % len(node.choices)
            elif k == "enter":
                self.cur, self.top = old_cur, old_top
                return True
            elif k == "esc":
                app.s.clear()
                app.s.update(saved)
                app.apply_style()
                self.cur, self.top = old_cur, old_top
                return False
            else:
                continue
            node.set(node.choices[idx][0])
            if node.style:
                app.apply_style()

    # --- změny ---
    def changed(self, n):
        app = self.app
        app.save()
        if n.style:
            app.apply_style()
        if n.sysref:
            app.refresh_system()
        self.reload = self.reload or bool(n.reload)
        self.restart = self.restart or bool(n.restart)

    def edit(self, n):
        app = self.app
        if n.typ == "bool":
            n.set(not n.get())
        elif n.typ == "choice":
            if not self.popup(n):
                return
        elif n.typ == "number":
            v = self.ask_text(f"{n.label} ({n.lo}–{n.hi}), Enter = beze změny:")
            if not v or not v.strip():
                return
            try:
                x = float(v.replace(",", "."))
                x = max(n.lo, min(n.hi, x))
                n.set(round(x, 2) if isinstance(n.step, float) else int(round(x)))
            except ValueError:
                self.msg = "Neplatné číslo."
                return
        elif n.typ == "text":
            v = self.ask_text(f"{n.label} (Enter = beze změny, '-' = prázdné):")
            if v is None or v == "":
                return
            n.set("" if v.strip() == "-" else v)
        elif n.typ == "color":
            v = self.ask_text(f"{n.label} – hex barva (např. #ff7a00):")
            if not v or not HEX.fullmatch(v.strip()):
                if v:
                    self.msg = "Neplatná barva, použij tvar #rrggbb."
                return
            n.set("#" + v.strip().lstrip("#").lower())
        elif n.typ == "aliases":
            al = dict(app.s.get("aliases", {}))
            cur = ", ".join(f"{k}={v}" for k, v in al.items())[:60] or "žádné"
            v = self.ask_text(f"Alias zkratka=text (nyní: {cur}) · smazat: zkratka=")
            if not v or "=" not in v:
                return
            k, _, val = v.partition("=")
            k = k.strip().lstrip("/").lower()
            if not k:
                return
            if val.strip():
                al[k] = val.strip()
            else:
                al.pop(k, None)
            app.s["aliases"] = al
        elif n.typ == "action":
            if getattr(n, "confirm", False):
                v = self.ask_text(f"{n.label}? Napiš 'ano' pro potvrzení:")
                if (v or "").strip().lower() != "ano":
                    return
            res = n.fn()
            self.msg = res if isinstance(res, str) else "✔ Hotovo."
        self.changed(n)

    def bump(self, n, d):
        if n.typ == "bool":
            n.set(not n.get())
        elif n.typ == "number":
            v = float(n.get() or 0) + d * n.step
            v = max(n.lo, min(n.hi, v))
            n.set(round(v, 2) if isinstance(n.step, float) else int(round(v)))
        elif n.typ == "choice":
            i = next((i for i, (val, _) in enumerate(n.choices) if str(val) == str(n.get())), 0)
            n.set(n.choices[(i + d) % len(n.choices)][0])
        else:
            return
        self.changed(n)

    def reset_item(self, n):
        app = self.app
        if n.reset:
            n.reset()
        elif n.key == "theme":
            n.set(app.defaults["theme"])
        elif n.key in app.defaults and n.key not in ("workdir",):
            app.s[n.key] = app.defaults[n.key]
        else:
            return
        self.msg = "↺ Vráceno na výchozí."
        self.changed(n)

    # --- hlavní smyčka ---
    def handle(self, k):
        self.msg = ""
        rows = self.visible()
        n, depth = rows[self.cur]
        if k in ("esc", "q"):
            return False
        if k == "up":
            self.cur = max(0, self.cur - 1)
        elif k == "down":
            self.cur = min(len(rows) - 1, self.cur + 1)
        elif k == "home":
            self.cur = 0
        elif k == "end":
            self.cur = len(rows) - 1
        elif k == "pgup":
            self.cur = max(0, self.cur - 8)
        elif k == "pgdn":
            self.cur = min(len(rows) - 1, self.cur + 8)
        elif k == "left":
            if n.typ == "cat":
                if n.expanded:
                    n.expanded = False
                else:
                    par = self.parent_of(n)
                    if par:
                        par.expanded = False
                        self.cur = next(i for i, (x, _) in enumerate(self.visible()) if x is par)
            else:
                par = self.parent_of(n)
                if par:
                    par.expanded = False
                    self.cur = next(i for i, (x, _) in enumerate(self.visible()) if x is par)
        elif k == "right":
            if n.typ == "cat":
                if not n.expanded:
                    n.expanded = True
                else:
                    self.cur = min(len(rows) - 1, self.cur + 1)
            else:
                self.edit(n)
        elif k == "enter":
            if n.typ == "cat":
                n.expanded = not n.expanded
            else:
                self.edit(n)
        elif k in ("+", "="):
            self.bump(n, 1)
        elif k in ("-", "_"):
            self.bump(n, -1)
        elif k in ("r", "del"):
            self.reset_item(n)
        return True

    def run(self):
        out = sys.stdout
        out.write("\033[?1049h\033[?25l")
        out.flush()
        try:
            while True:
                self.draw()
                if not self.handle(read_key()):
                    break
        finally:
            out.write("\033[?25h\033[?1049l")
            out.flush()


def _cmd(app, arg):
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        app.cmd_settings("")
        return
    ui = UI(app)
    app.pin_off()
    ui.run()
    app.save()
    if ui.reload:
        app.say("⟳ Změnil se kontext/GPU/vlákna – načítám model znovu…")
        app.llm = None
        app.load_llm()
    app.refresh_system()
    app.update_ctx()
    app.header()
    if ui.restart:
        app.say("Změna modulů se projeví po restartu.")


def register(app):
    app.add_command("nastaveni", _cmd, "okno nastavení (motiv, zarovnání, vlastní věci…)")
    app.add_command("settings", _cmd, "okno nastavení")
