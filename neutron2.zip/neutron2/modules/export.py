import html
import re
import webbrowser
from datetime import datetime

NAME = "Export"
DESCRIPTION = "/export: uloží konverzaci jako HTML v barvách aktuálního motivu"


def _md(text):
    out, parts = [], re.split(r"```(\w*)\n(.*?)```", html.escape(text), flags=re.S)
    for i in range(0, len(parts), 3):
        seg = parts[i]
        seg = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", seg)
        seg = re.sub(r"`([^`]+)`", r"<code>\1</code>", seg)
        out.append(seg.replace("\n", "<br>"))
        if i + 2 < len(parts):
            out.append(f'<pre><span class="lang">{parts[i + 1] or "kód"}</span>{parts[i + 2]}</pre>')
    return "".join(out)


def _cmd(app, arg):
    d = app.theme.d
    a, b = d["accent"], d.get("accent2", d["accent"])
    rows = []
    for m in app.messages[1:]:
        text = m["content"]
        if m["role"] == "user" and text.startswith("[VÝSLEDEK NÁSTROJE"):
            rows.append(f'<details><summary>⚙ výsledek nástroje</summary><pre>{html.escape(text)}</pre></details>')
            continue
        who = "Ty" if m["role"] == "user" else "Neutron"
        rows.append(f'<div class="m {m["role"]}"><div class="who">{who}</div>{_md(text)}</div>')
    page = f"""<!doctype html><html lang="cs"><meta charset="utf-8"><title>Neutron – {datetime.now():%d.%m.%Y %H:%M}</title>
<style>
body{{background:#0e0f13;color:#e6e6e6;font:16px/1.6 system-ui,sans-serif;max-width:820px;margin:40px auto;padding:0 16px}}
h1{{background:linear-gradient(90deg,{a},{b});-webkit-background-clip:text;color:transparent;letter-spacing:.2em}}
.m{{padding:12px 16px;margin:14px 0;border-radius:10px;background:#16181f;border-left:4px solid {b}}}
.m.assistant{{border-left-color:{a}}} .who{{font-size:12px;color:{a};text-transform:uppercase;letter-spacing:.1em;margin-bottom:4px}}
code{{background:#262a34;color:{b};padding:1px 5px;border-radius:4px}} pre{{background:#0a0b0e;border:1px solid #2a2d38;padding:12px;border-radius:8px;overflow:auto;color:{b}}}
.lang{{display:block;font-size:11px;color:{a};margin-bottom:6px}} details{{color:#888;margin:8px 0}}
</style><h1>NEUTRON</h1>{''.join(rows)}</html>"""
    out = app.base / "chats"
    out.mkdir(exist_ok=True)
    f = out / f"chat_{datetime.now():%Y%m%d_%H%M%S}.html"
    f.write_text(page, encoding="utf-8")
    app.say(f"✔ Exportováno: {f}", "ok")
    webbrowser.open(f.as_uri())


def register(app):
    app.add_command("export", _cmd, "uloží chat jako HTML a otevře ho v prohlížeči")
