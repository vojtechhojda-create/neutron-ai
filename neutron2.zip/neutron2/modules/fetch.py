import html as htmllib
import re
import urllib.request

NAME = "Čtení webu"
DESCRIPTION = "fetch_url: stáhne stránku a vrátí z ní text (potřebuje internet)"


def _fetch(app, arg, body):
    url = arg if arg.startswith(("http://", "https://")) else "https://" + arg
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 Neutron"})
    with urllib.request.urlopen(req, timeout=15) as r:
        raw = r.read(600_000)
        enc = r.headers.get_content_charset() or "utf-8"
    page = raw.decode(enc, errors="replace")
    page = re.sub(r"(?is)<(script|style|noscript|svg).*?</\1>", " ", page)
    text = htmllib.unescape(re.sub(r"(?s)<[^>]+>", " ", page))
    return re.sub(r"\s+", " ", text).strip()[:3500]


def register(app):
    app.add_tool("fetch_url", _fetch, "stáhne webovou stránku a vrátí její text (arg = adresa)")
