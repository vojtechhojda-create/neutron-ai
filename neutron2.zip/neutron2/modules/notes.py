import json
from pathlib import Path

NAME = "Paměť"
DESCRIPTION = "dlouhodobé poznámky: remember/recall, /pamet, vkládá se do promptu"

FILE = Path(__file__).resolve().parent.parent / "memory.json"


def _load():
    try:
        return json.loads(FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(d):
    FILE.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")


def _remember(app, arg, body):
    d = _load()
    d[arg.strip()] = (body or arg).strip()
    _save(d)
    app.refresh_system()
    return f"Uloženo: {arg}"


def _recall(app, arg, body):
    q = arg.lower()
    hits = [f"{k}: {v}" for k, v in _load().items() if q in k.lower() or q in v.lower()]
    return "\n".join(hits) or "Nic takového v paměti není."


def _hook(app):
    d = _load()
    if not d:
        return None
    lines = [f"- {k}: {v}" for k, v in list(d.items())[-20:]]
    return "Trvalé poznámky, které si máš pamatovat:\n" + "\n".join(lines)


def _cmd(app, arg):
    d = _load()
    sub, _, rest = arg.partition(" ")
    if sub == "zapomen" and rest:
        if d.pop(rest.strip(), None) is not None:
            _save(d)
            app.refresh_system()
            app.say(f"✔ Zapomenuto: {rest}", "ok")
        else:
            app.say("Takový klíč neexistuje.", "err")
    elif sub == "smaz":
        _save({})
        app.refresh_system()
        app.say("✔ Paměť vymazána.", "ok")
    elif sub == "pridej" and rest:
        k, _, v = rest.partition("=")
        d[k.strip()] = v.strip() or k.strip()
        _save(d)
        app.refresh_system()
        app.say(f"✔ Uloženo: {k.strip()}", "ok")
    else:
        if not d:
            app.say("Paměť je prázdná. /pamet pridej klíč = hodnota")
        for k, v in d.items():
            print(f"  {app.theme.b}{k}{app.theme.dim}: {v}\033[0m")
        app.say("/pamet pridej k = v · /pamet zapomen k · /pamet smaz")


def register(app):
    app.add_tool("remember", _remember, "uloží trvalou poznámku (arg = klíč, tělo = text)")
    app.add_tool("recall", _recall, "vyhledá v poznámkách (arg = hledaný výraz)")
    app.add_prompt_hook(_hook)
    app.add_command("pamet", _cmd, "dlouhodobá paměť (list / pridej / zapomen / smaz)")
