import re

NAME = "Přílohy @soubor"
DESCRIPTION = "v textu zprávy napiš @soubor.py a jeho obsah se připojí (Tab doplňuje)"

PAT = re.compile(r"(?<!\S)@([^\s@]+)")
LIMIT = 8000


def _filter(app, text):
    out, seen = [], set()
    for m in PAT.finditer(text):
        rel = m.group(1).rstrip(".,;:!?)")
        if rel in seen:
            continue
        try:
            p = app.resolve(rel)
        except Exception:
            continue
        if p.is_dir():
            items = sorted(x.name + ("/" if x.is_dir() else "") for x in p.iterdir())[:80]
            out.append(f"[PŘÍLOHA složka {rel}]\n" + "\n".join(items))
            app.say(f"📎 {rel}/ ({len(items)} položek)")
        elif p.is_file():
            data = p.read_bytes()[:LIMIT * 4]
            if b"\0" in data:
                continue
            body = data.decode("utf-8", errors="replace")
            cut = len(body) > LIMIT
            out.append(f"[PŘÍLOHA {rel}]\n```\n{body[:LIMIT]}{' …(zkráceno)' if cut else ''}\n```")
            app.say(f"📎 {rel} ({min(len(body), LIMIT)} znaků{', zkráceno' if cut else ''})")
        else:
            continue
        seen.add(rel)
    return text + ("\n\n" + "\n\n".join(out) if out else "")


def register(app):
    app.add_input_filter(_filter)
