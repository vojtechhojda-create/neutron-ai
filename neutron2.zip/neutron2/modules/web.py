import os
import subprocess
import urllib.parse
import webbrowser

NAME = "Web a aplikace"
DESCRIPTION = "open_url, web_search, open_app (vždy s potvrzením)"

_BAD = set('&|<>^%"')


def _url(app, arg, body):
    if not arg.startswith(("http://", "https://")):
        arg = "https://" + arg
    webbrowser.open(arg)
    return f"Otevřeno: {arg}"


def _search(app, arg, body):
    webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote_plus(arg))
    return f"Hledání otevřeno v prohlížeči: {arg}"


def _app(app, arg, body):
    if any(c in _BAD for c in arg):
        raise ValueError("nepovolené znaky v názvu")
    if os.name == "nt":
        subprocess.Popen(["cmd", "/c", "start", "", arg])
    else:
        subprocess.Popen([arg])
    return f"Spuštěno: {arg}"


def register(app):
    app.add_tool("open_url", _url, "otevře web v prohlížeči (arg = adresa)", dangerous=True)
    app.add_tool("web_search", _search, "vyhledá v prohlížeči (arg = dotaz)", dangerous=True)
    app.add_tool("open_app", _app, "spustí aplikaci (arg = název, např. notepad)", dangerous=True)
