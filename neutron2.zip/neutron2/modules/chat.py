import time

NAME = "Chat nástroje"
DESCRIPTION = "/retry /undo /compact /system /stats /set /bench + automatické shrnování kontextu"

SKIP_PREFIX = ("[VÝSLEDEK NÁSTROJE", "[SHRNUTÍ", "Pokračuj:", "Odpověz platným")
RELOAD = {"n_ctx", "n_gpu_layers", "n_threads"}


def _last_user(app):
    for i in range(len(app.messages) - 1, 0, -1):
        m = app.messages[i]
        if m["role"] == "user" and not m["content"].startswith(SKIP_PREFIX):
            return i
    return None


def _retry(app, arg):
    i = _last_user(app)
    if i is None:
        app.say("Není co opakovat.", "err")
        return
    app.messages = app.messages[:i + 1]
    app.agent(4)
    app._after_turn()


def _undo(app, arg):
    i = _last_user(app)
    if i is None:
        app.say("Není co vracet.", "err")
        return
    app.messages = app.messages[:i]
    app.update_ctx()
    app.say("✔ Poslední výměna odstraněna.", "ok")


def _system(app, arg):
    import textwrap
    lines = []
    for para in app.messages[0]["content"].splitlines():
        lines.extend(textwrap.wrap(para, 90) or [""])
    app.panel("Systémový prompt", lines)


def _stats(app, arg):
    st = app.stats
    up = time.time() - st["started"]
    avg = st["tokens"] / st["gen_time"] if st["gen_time"] else 0
    frac = app.ctx_used / max(int(app.s["n_ctx"]), 1)
    d = app.theme.dim
    z = "\033[0m"
    rows = [("výměn", str(st["turns"])), ("vygenerováno", f"{st['tokens']} tokenů"), ("průměr", f"{avg:.1f} tok/s"),
            ("volání nástrojů", str(st["tools"])), ("kontext", f"{app.ctx_used} / {app.s['n_ctx']} ({frac * 100:.0f} %)"),
            ("běží", f"{int(up // 60)} min {int(up % 60)} s")]
    lines = [f"{d}{k.ljust(16)}{z}{v}" for k, v in rows]
    app.panel("Statistiky", lines)


def _set(app, arg):
    key, _, val = arg.partition(" ")
    if not key:
        for k, v in app.s.items():
            if k not in ("system_prompt", "disabled_modules", "settings_v"):
                print(f"  {app.theme.b}{k:<14}\033[0m{app.theme.dim}{str(v)[:60]}\033[0m")
        app.say("Změna: /set klíč hodnota   (např. /set temperature 0.3)")
        return
    if key not in app.s:
        app.say(f"Neznámý klíč '{key}'. /set ukáže seznam.", "err")
        return
    cur = app.s[key]
    try:
        if isinstance(cur, bool):
            new = val.strip().lower() in ("1", "true", "ano", "on", "zapnout")
        elif isinstance(cur, int):
            new = int(val)
        elif isinstance(cur, float):
            new = float(val)
        else:
            new = int(val) if key == "n_gpu_layers" and val.strip().lstrip("-").isdigit() else val
    except ValueError:
        app.say("Neplatná hodnota.", "err")
        return
    app.s[key] = new
    app.save()
    app.refresh_system()
    app.say(f"✔ {key} = {new}" + ("  (projeví se po /model nebo restartu)" if key in RELOAD else ""), "ok")


def _bench(app, arg):
    sp = app.Spinner("benchmark")
    sp.start()
    t0, t1, n, stopped = time.time(), None, 0, False
    try:
        for ch in app.llm.create_chat_completion(messages=[{"role": "user", "content": "Napiš odstavec o Měsíci."}],
                                                 max_tokens=128, temperature=0.0, stream=True):
            if t1 is None:
                t1 = time.time()
                sp.stop()
                stopped = True
            if ch["choices"][0]["delta"].get("content"):
                n += 1
    finally:
        if not stopped:
            sp.stop()
    if t1 is None:
        app.say("Model nic nevrátil.", "err")
        return
    gen = max(time.time() - t1, 1e-6)
    lines = [f"{app.theme.dim}načtení promptu \033[0m{t1 - t0:.2f} s",
             f"{app.theme.dim}generování      \033[0m{n} tok za {gen:.1f} s",
             f"{app.theme.dim}rychlost        \033[0m{app.theme.b}{n / gen:.1f} tok/s\033[0m"]
    app.panel("Benchmark", lines)


def compact(app, keep_last=4):
    msgs = app.messages
    if len(msgs) <= keep_last + 3:
        return False
    old, tail = msgs[1:-keep_last], list(msgs[-keep_last:])
    while tail and tail[0]["role"] != "user":
        tail.pop(0)
    text = "\n".join(f"{m['role']}: {m['content'][:1200]}" for m in old)
    text = text[: int(app.s["n_ctx"]) * 2]
    sp = app.Spinner("shrnuji starší část konverzace")
    sp.start()
    try:
        r = app.llm.create_chat_completion(
            messages=[{"role": "system", "content": "Stručně česky shrň tuto konverzaci: klíčová fakta, rozhodnutí a stav práce. Maximálně 150 slov."},
                      {"role": "user", "content": text}],
            max_tokens=300, temperature=0.2)
        summary = r["choices"][0]["message"]["content"].strip()
    finally:
        sp.stop()
    if not summary:
        return False
    app.messages = [msgs[0],
                    {"role": "user", "content": "[SHRNUTÍ DOSAVADNÍ KONVERZACE]\n" + summary},
                    {"role": "assistant", "content": "Rozumím, pokračujeme."}] + tail
    app.say("⟲ Starší část konverzace shrnuta, kontext uvolněn.", "ok")
    return True


def _compact_cmd(app, arg):
    if not compact(app):
        app.say("Konverzace je zatím příliš krátká na shrnutí.")
    app.update_ctx()


def register(app):
    app.add_trim_hook(lambda a, total, limit: bool(a.s.get("auto_compact", True)) and compact(a))
    for n, f, h in [("retry", _retry, "znovu vygeneruje poslední odpověď"),
                    ("undo", _undo, "odstraní poslední výměnu"),
                    ("compact", _compact_cmd, "shrne starou konverzaci a uvolní kontext"),
                    ("system", _system, "ukáže aktuální systémový prompt"),
                    ("stats", _stats, "statistiky relace"),
                    ("set", _set, "rychlá změna nastavení: /set temperature 0.3"),
                    ("bench", _bench, "změří rychlost modelu (tok/s)")]:
        app.add_command(n, f, h)
