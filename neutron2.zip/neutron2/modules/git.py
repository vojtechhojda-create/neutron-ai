import subprocess

NAME = "Git"
DESCRIPTION = "git_status, git_diff, git_log (čtení) + git_commit (s potvrzením), /git"


def _git(app, *args):
    try:
        r = subprocess.run(["git", *args], cwd=app.workdir, capture_output=True, text=True,
                           timeout=30, encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return "Git není nainstalovaný."
    return (r.stdout + r.stderr).strip() or "(bez výstupu)"


def register(app):
    app.add_tool("git_status", lambda a, arg, b: _git(a, "status", "--short", "--branch"), "stav git repozitáře")
    app.add_tool("git_diff", lambda a, arg, b: _git(a, "diff", "--stat", *( [arg] if arg else [])) + "\n" + _git(a, "diff", *( [arg] if arg else []))[:2500],
                 "změny v repozitáři (arg = soubor, volitelné)")
    app.add_tool("git_log", lambda a, arg, b: _git(a, "log", "--oneline", "-n", "15"), "posledních 15 commitů")
    app.add_tool("git_commit", lambda a, arg, b: _git(a, "add", "-A") + "\n" + _git(a, "commit", "-m", arg or "update"),
                 "přidá všechny změny a vytvoří commit (arg = zpráva)", dangerous=True)
    app.add_command("git", lambda a, arg: print("\n".join("  " + l for l in _git(a, *arg.split()).splitlines())) if arg else a.say("Použití: /git status | log | diff"),
                    "spustí git příkaz v pracovní složce")
