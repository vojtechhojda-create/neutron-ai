NAME = "Schránka"
DESCRIPTION = "clipboard_get/clipboard_set + /clip (pošle schránku modelu)"


def _tk():
    import tkinter as tk
    r = tk.Tk()
    r.withdraw()
    return r


def _get(app, arg, body):
    r = _tk()
    try:
        return r.clipboard_get()
    finally:
        r.destroy()


def _set(app, arg, body):
    text = body or arg
    r = _tk()
    try:
        r.clipboard_clear()
        r.clipboard_append(text)
        r.update()
    finally:
        r.destroy()
    return f"Do schránky zkopírováno {len(text)} znaků."


def _cmd(app, arg):
    text = _get(app, "", "")
    if not text.strip():
        app.say("Schránka je prázdná.", "err")
        return
    app.say(f"Ze schránky načteno {len(text)} znaků.")
    app.ask((arg + "\n\n" if arg else "") + text)


def register(app):
    app.add_tool("clipboard_get", _get, "vrátí text ze schránky")
    app.add_tool("clipboard_set", _set, "zkopíruje text z těla značky do schránky", dangerous=True)
    app.add_command("clip", _cmd, "pošle obsah schránky modelu (/clip přelož to)")
