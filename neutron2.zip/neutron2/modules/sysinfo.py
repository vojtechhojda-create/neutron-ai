import os
import platform
import shutil

NAME = "Systém"
DESCRIPTION = "sysinfo + /sys: CPU, RAM, disk, verze Pythonu"


def _ram():
    try:
        if os.name == "nt":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.ullTotalPhys, m.ullAvailPhys
        info = {}
        for line in open("/proc/meminfo"):
            k, v = line.split(":")
            info[k] = int(v.split()[0]) * 1024
        return info["MemTotal"], info["MemAvailable"]
    except Exception:
        return None


def _info(app, arg, body):
    gb = lambda b: f"{b / 1e9:.1f} GB"
    lines = [f"OS: {platform.system()} {platform.release()}", f"CPU jader: {os.cpu_count()}",
             f"Python: {platform.python_version()}"]
    ram = _ram()
    if ram:
        lines.append(f"RAM: {gb(ram[1])} volných z {gb(ram[0])}")
    d = shutil.disk_usage(app.workdir)
    lines.append(f"Disk pracovní složky: {gb(d.free)} volných z {gb(d.total)}")
    return "\n".join(lines)


def register(app):
    app.add_tool("sysinfo", _info, "vrátí informace o počítači (CPU, RAM, disk)")
    app.add_command("sys", lambda a, arg: print("\n".join("  " + l for l in _info(a, "", "").splitlines())), "informace o počítači")
