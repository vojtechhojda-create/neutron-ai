NAME = "Persony"
DESCRIPTION = "/persona: přepíná styl a roli asistenta"

PERSONAS = {
    "Výchozí": "",
    "Programátor": "Chováš se jako zkušený programátor. Odpovídej přesně, dávej funkční kód v blocích a stručně vysvětli proč.",
    "Učitel": "Chováš se jako trpělivý učitel. Vysvětluj postupně, jednoduše, s příklady, a na konci ověř porozumění otázkou.",
    "Překladatel": "Jsi překladatel. Uživatelův text přelož do druhého jazyka (česky ↔ anglicky) a nic dalšího nepřidávej.",
    "Stručný": "Odpovídej maximálně dvěma větami. Žádné úvody ani shrnutí.",
    "Kritik": "Buď upřímný kritik. Hledej slabá místa v nápadech a textech, pojmenuj je konkrétně a navrhni zlepšení.",
}


def _hook(app):
    t = PERSONAS.get(app.s.get("persona", "Výchozí"), "")
    return f"Role: {t}" if t else None


def _cmd(app, arg):
    names = list(PERSONAS)
    pick = None
    if arg and arg in names:
        pick = arg
    else:
        i = app.menu("Vyber personu (Esc = zpět):", [f"{n}  {app.theme.dim}{PERSONAS[n][:55]}\033[0m" for n in names],
                     start=names.index(app.s.get("persona", "Výchozí")) if app.s.get("persona") in names else 0)
        if i is not None:
            pick = names[i]
    if pick:
        app.s["persona"] = pick
        app.save()
        app.refresh_system()
        app.say(f"✔ Persona: {pick}", "ok")


def register(app):
    app.add_prompt_hook(_hook)
    app.add_command("persona", _cmd, "změní roli/styl asistenta")
