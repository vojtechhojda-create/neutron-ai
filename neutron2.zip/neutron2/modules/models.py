"""Správce modelů: ověřený katalog, doporučení podle RAM, stahování s obnovením, přepínání a mazání."""
import http.client
import os
import shutil
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

try:
    import msvcrt
except ImportError:
    msvcrt = None

NAME = "Správce modelů"
DESCRIPTION = "/models: katalog, doporučení podle RAM, stahování s ukazatelem a obnovením, přepínání, mazání"

RST = "\033[0m"

# Názvy repozitářů a souborů ověřeny z veřejných zdrojů (Hugging Face / katalogy projektů); velikosti jsou přibližné.
CATALOG = [
    dict(name="Qwen2.5 3B", repo="Qwen/Qwen2.5-3B-Instruct-GGUF", file="qwen2.5-3b-instruct-q4_k_m.gguf",
         size=2.1, ram=4, desc="malý a rychlý, slabší čeština – pro starší počítače"),
    dict(name="Qwen3 4B", repo="unsloth/Qwen3-4B-GGUF", file="Qwen3-4B-Q4_K_M.gguf",
         size=2.5, ram=6, desc="dobrý univerzál, umí myslet nahlas (<think>)"),
    dict(name="Qwen3 8B", repo="unsloth/Qwen3-8B-GGUF", file="Qwen3-8B-Q4_K_M.gguf",
         size=5.0, ram=10, desc="nejlepší poměr kvality a rychlosti, lepší čeština"),
    dict(name="Qwen3 14B", repo="unsloth/Qwen3-14B-GGUF", file="Qwen3-14B-Q4_K_M.gguf",
         size=9.0, ram=20, desc="vysoká kvalita, na CPU pomalejší"),
    dict(name="Gemma 4 E4B", repo="ggml-org/gemma-4-E4B-it-GGUF", file="gemma-4-E4B-it-Q4_K_M.gguf",
         size=5.0, ram=8, desc="nejnovější od Googlu, výborná vícejazyčnost",
         warn="Vyžaduje novou llama-cpp-python. Starší verze model nenačtou (zkus pip install -U llama-cpp-python)."),
]


def _ram():
    """(celkem, volné) v bajtech, nebo None."""
    try:
        if os.name == "nt":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.ullTotalPhys, m.ullAvailPhys
        info = {}
        for line in open("/proc/meminfo"):
            k, v = line.split(":")
            info[k] = int(v.split()[0]) * 1024
        return info["MemTotal"], info["MemAvailable"]
    except Exception:
        return None


def recommend(total_gb):
    """Největší model, který se pohodlně vejde do RAM (bez těch s varováním)."""
    ok = [e for e in CATALOG if not e.get("warn") and e["ram"] <= (total_gb or 0)]
    return max(ok, key=lambda e: e["ram"]) if ok else CATALOG[0]


def _stop_pressed():
    if not msvcrt:
        return False
    hit = False
    while msvcrt.kbhit():
        k = msvcrt.getwch()
        if k == "\x1b":
            hit = True
        elif k in ("\x00", "\xe0") and msvcrt.getwch() == "O":
            hit = True
    return hit


def _bar(app, got, total, speed, width=24):
    T = app.theme
    frac = got / total if total else 0
    k = round(width * frac)
    eta = ""
    if speed > 0 and total:
        sec = int((total - got) / speed)
        eta = f" · ETA {sec // 60}:{sec % 60:02d}"
    return (f"  {T.a}{'▰' * k}{T.dim}{'▱' * (width - k)}{RST} {frac * 100:3.0f} % "
            f"{T.dim}{got / 1e9:.2f}/{total / 1e9:.2f} GB · {speed / 1e6:.1f} MB/s{eta}  (End = pauza){RST}\033[K")


def download(app, entry, dest_dir):
    """Stáhne soubor s ukazatelem a obnovením (.part). Vrací Path, nebo None při přerušení."""
    url = entry.get("url") or f"https://huggingface.co/{entry['repo']}/resolve/main/{entry['file']}"
    dest = Path(dest_dir) / entry["file"]
    part = dest.with_name(dest.name + ".part")
    dest.parent.mkdir(parents=True, exist_ok=True)
    start = part.stat().st_size if part.exists() else 0

    def open_url(offset):
        h = {"User-Agent": "Neutron/3.2"}
        if offset:
            h["Range"] = f"bytes={offset}-"
        return urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=30)

    try:
        try:
            resp = open_url(start)
        except urllib.error.HTTPError as e:
            if e.code == 416 and start:  # neplatný rozsah → začít znovu
                part.unlink(missing_ok=True)
                start = 0
                resp = open_url(0)
            else:
                raise
        with resp:
            if resp.status == 206:
                total = int(resp.headers["Content-Range"].split("/")[-1])
                mode = "ab"
            else:
                start, mode = 0, "wb"
                total = int(resp.headers.get("Content-Length") or 0)
            free = shutil.disk_usage(dest.parent).free
            if total and free < (total - start) + 200_000_000:
                app.say(f"✖ Málo místa na disku: potřeba {(total - start) / 1e9:.1f} GB, volné {free / 1e9:.1f} GB.", "err")
                return None
            if start:
                app.say(f"Pokračuji ve stahování od {start / 1e9:.2f} GB…")
            got, t0, last = start, time.time(), 0.0
            _stop_pressed()
            with open(part, mode) as f:
                while True:
                    chunk = resp.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
                    got += len(chunk)
                    now = time.time()
                    if now - last > 0.2:
                        last = now
                        sys.stdout.write("\r" + _bar(app, got, total, (got - start) / max(now - t0, 1e-6)))
                        sys.stdout.flush()
                    if _stop_pressed():
                        sys.stdout.write("\n")
                        app.say("⏸ Stahování pozastaveno – příště naváže tam, kde skončilo.", "dim")
                        return None
            sys.stdout.write("\r" + _bar(app, got, total or got, (got - start) / max(time.time() - t0, 1e-6)) + "\n")
        if total and part.stat().st_size != total:
            app.say(f"✖ Stahování se přerušilo ({part.stat().st_size} z {total} bajtů). Spusť znovu – naváže.", "err")
            return None
        part.replace(dest)
        app.say(f"✔ Staženo: {dest.name}", "ok")
        return dest
    except KeyboardInterrupt:
        sys.stdout.write("\n")
        app.say("⏸ Přerušeno – částečný soubor zůstal, příště naváže.", "dim")
        return None
    except (http.client.IncompleteRead, ConnectionError, TimeoutError):
        sys.stdout.write("\n")
        app.say("✖ Spojení se přerušilo. Spusť stahování znovu – naváže tam, kde skončilo.", "err")
    except urllib.error.HTTPError as e:
        app.say(f"✖ Server vrátil chybu {e.code} ({e.reason}). Zkontroluj repozitář a název souboru.", "err")
    except Exception as e:
        app.say(f"✖ Stažení selhalo: {e}", "err")
    return None


# ───────────────────────── nabídky ─────────────────────────
def _installed(app):
    d = app.base / "models"
    d.mkdir(exist_ok=True)
    return sorted(d.rglob("*.gguf"))


def _ram_line(app):
    ram = _ram()
    if not ram:
        return None, "RAM se nepodařilo zjistit"
    tot, free = ram[0] / 1e9, ram[1] / 1e9
    rec = recommend(tot)
    return tot, f"RAM: {free:.1f} GB volných z {tot:.1f} GB · doporučeno: {rec['name']}"


def _catalog_flow(app):
    T = app.theme
    tot, line = _ram_line(app)
    rec = recommend(tot or 0)
    have = {p.name for p in _installed(app)}
    labels = []
    for e in CATALOG:
        tags = []
        if e["file"] in have:
            tags.append(f"{T.ok}✔ nainstalováno{RST}")
        if e is rec and tot:
            tags.append(f"{T.b}★ doporučeno{RST}")
        if e.get("warn"):
            tags.append(f"{T.err}⚠ ověř kompatibilitu{RST}")
        if tot and e["ram"] > tot:
            tags.append(f"{T.err}málo RAM{RST}")
        labels.append(f"{e['name']:<12} ≈{e['size']:.1f} GB  {T.dim}{e['desc']}{RST}  " + " ".join(tags))
    labels += ["＋ Vlastní repozitář / odkaz", "Zpět"]
    print(f"  {T.dim}{line}{RST}")
    i = app.menu("Stáhnout model (Esc = zpět):", labels)
    if i is None or i == len(labels) - 1:
        return None
    if i == len(labels) - 2:
        repo = input("  Repozitář (např. unsloth/Qwen3-8B-GGUF): ").strip()
        fname = input("  Soubor (např. Qwen3-8B-Q4_K_M.gguf): ").strip()
        if not repo or not fname.endswith(".gguf"):
            app.say("Zadej repozitář a název souboru končící na .gguf.", "err")
            return None
        entry = dict(repo=repo, file=fname, name=fname)
    else:
        entry = CATALOG[i]
        if entry.get("warn"):
            app.say(entry["warn"], "err")
            if input("  Přesto stáhnout? [a/N] ").strip().lower() not in ("a", "ano", "y"):
                return None
    if entry["file"] in have:
        app.say("Tento model už máš.", "ok")
        return app.base / "models" / entry["file"]
    return download(app, entry, app.base / "models")


def _switch(app, path):
    prev = app.model_path
    app.llm = None
    app.set_model_path(path)
    app.header(path.name, info=False)
    if not app.load_llm():
        app.say("Vracím se k předchozímu modelu…", "err")
        app.set_model_path(prev)
        app.load_llm()
    app.reset_chat()
    app.header()


def _models_cmd(app, arg):
    T = app.theme
    while True:
        files = _installed(app)
        tot, line = _ram_line(app)
        labels = []
        for f in files:
            active = app.model_path and f.resolve() == app.model_path.resolve()
            mark = f"{T.ok}● aktivní{RST}" if active else ""
            labels.append(f"{f.name}  {T.dim}({f.stat().st_size / 1e9:.1f} GB){RST} {mark}")
        n = len(files)
        labels += ["＋ Stáhnout model z katalogu", "✖ Smazat model", "Zpět"]
        print()
        print(f"  {T.dim}{line}{RST}")
        i = app.menu("Modely – Enter přepne na vybraný model:", labels)
        if i is None or i == n + 2:
            return
        if i < n:
            if app.model_path and files[i].resolve() == app.model_path.resolve():
                app.say("Tento model už je aktivní.")
                continue
            _switch(app, files[i])
        elif i == n:
            p = _catalog_flow(app)
            if p and input("  Přepnout na tento model? [A/n] ").strip().lower() in ("", "a", "ano", "y"):
                _switch(app, p)
        elif i == n + 1:
            if not files:
                app.say("Není co mazat.")
                continue
            j = app.menu("Který model smazat? (Esc = zpět)", [f.name for f in files])
            if j is None:
                continue
            if app.model_path and files[j].resolve() == app.model_path.resolve():
                app.say("Aktivní model nelze smazat – nejdřív přepni na jiný.", "err")
            elif input(f"  Opravdu smazat {files[j].name}? Napiš 'ano': ").strip().lower() == "ano":
                files[j].unlink()
                app.say("✔ Smazáno.", "ok")


def _hook(app):
    """Qwen3 umí vypnout dlouhé přemýšlení značkou /no_think – chat je pak výrazně rychlejší."""
    name = (app.model_path.name if app.model_path else "").lower()
    if app.s.get("no_think") and "qwen3" in name:
        return "/no_think"
    return None


def register(app):
    app.download_hook = lambda a: _catalog_flow(a)
    app.add_prompt_hook(_hook)
    app.add_command("models", _models_cmd, "správce modelů: stáhnout, přepnout, smazat")
