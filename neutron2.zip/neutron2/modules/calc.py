import ast
import math
import operator as op

NAME = "Kalkulačka"
DESCRIPTION = "calc: bezpečné počítání (malé modely neumí aritmetiku)"

_OPS = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv, ast.FloorDiv: op.floordiv,
        ast.Mod: op.mod, ast.Pow: op.pow, ast.USub: op.neg, ast.UAdd: op.pos}
_FUN = {k: getattr(math, k) for k in ("sqrt", "sin", "cos", "tan", "log", "log10", "exp", "floor", "ceil", "fabs")}
_FUN.update(abs=abs, round=round, min=min, max=max)
_CONST = {"pi": math.pi, "e": math.e}


def _ev(n):
    if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
        return n.value
    if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
        a, b = _ev(n.left), _ev(n.right)
        if isinstance(n.op, ast.Pow) and abs(b) > 1000:
            raise ValueError("příliš velký exponent")
        return _OPS[type(n.op)](a, b)
    if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
        return _OPS[type(n.op)](_ev(n.operand))
    if isinstance(n, ast.Name) and n.id in _CONST:
        return _CONST[n.id]
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in _FUN:
        return _FUN[n.func.id](*[_ev(a) for a in n.args])
    raise ValueError("nepovolený výraz")


def _calc(app, arg, body):
    expr = (arg or body).replace(",", ".").replace("^", "**")
    return f"{expr} = {_ev(ast.parse(expr, mode='eval').body)}"


def register(app):
    app.add_tool("calc", _calc, "spočítá matematický výraz (arg = výraz, např. 12*(3+4)); umí sqrt, sin, log, pi")
    app.add_command("calc", lambda a, arg: a.say(_calc(a, arg, ""), "ok"), "rychlá kalkulačka")
