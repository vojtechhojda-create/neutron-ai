import json
from datetime import datetime

NAME = "Konverzace"
DESCRIPTION = "autosave každé výměny, /load, /continue"


def _dir(app):
    d = app.base / "sessions"
    d.mkdir(exist_ok=True)
    return d


def _save(app):
    if not app.s.get("autosave", True):
        return
    msgs = app.messages[1:]
    if not msgs:
        return
    if not app.session_id:
        app.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    first = next((m["content"] for m in msgs if m["role"] == "user"), "")
    title = first.strip().replace("\n", " ")[:50]
    data = {"title": title, "model": app.model_path.name if app.model_path else "", "messages": msgs}
    (_dir(app) / f"{app.session_id}.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")


def _load_file(app, f):
    data = json.loads(f.read_text(encoding="utf-8"))
    app.reset_chat()
    app.messages.extend(data["messages"])
    app.session_id = f.stem
    app.update_ctx()
    app.header()
    app.say(f"✔ Načteno {len(data['messages'])} zpráv: {data.get('title', '')}", "ok")
    last = next((m for m in reversed(app.messages) if m["role"] == "assistant"), None)
    if last:
        print()
        app.render(last["content"][:1500])


def _files(app):
    return sorted(_dir(app).glob("*.json"), reverse=True)


def _cmd_load(app, arg):
    files = _files(app)
    if not files:
        app.say("Zatím žádné uložené konverzace.")
        return
    labels = []
    for f in files[:15]:
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
            labels.append(f"{f.stem[:8]} {f.stem[9:11]}:{f.stem[11:13]}  {d.get('title', '')[:45]} "
                          f"{app.theme.dim}({len(d['messages'])} zpráv)\033[0m")
        except Exception:
            labels.append(f.stem)
    i = app.menu("Načíst konverzaci (Esc = zpět):", labels)
    if i is not None:
        _load_file(app, files[i])


def _cmd_continue(app, arg):
    files = _files(app)
    if not files:
        app.say("Zatím žádné uložené konverzace.")
        return
    _load_file(app, files[0])


def register(app):
    app.add_after_turn(_save)
    app.add_command("load", _cmd_load, "načte dřívější konverzaci")
    app.add_command("continue", _cmd_continue, "pokračuje v poslední konverzaci")
