import html as H
import re
import urllib.parse
import urllib.request

NAME = "Hledání na webu"
DESCRIPTION = "search_web: výsledky z DuckDuckGo (potřebuje internet), /hledej"


def _search(app, arg, body):
    url = "https://html.duckduckgo.com/html/?q=" + urllib.parse.quote_plus(arg)
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 Neutron"})
    page = urllib.request.urlopen(req, timeout=15).read().decode("utf-8", "replace")
    clean = lambda x: H.unescape(re.sub(r"<[^>]+>", "", x)).strip()
    results = []
    for m in re.finditer(r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>.*?class="result__snippet"[^>]*>(.*?)</a>', page, re.S):
        link, title, snip = m.groups()
        if "uddg=" in link:
            link = urllib.parse.unquote(link.split("uddg=")[1].split("&")[0])
        results.append(f"{len(results) + 1}. {clean(title)}\n   {link}\n   {clean(snip)[:200]}")
        if len(results) >= 6:
            break
    return "\n".join(results) or "Nic nenalezeno (nebo vyhledávač změnil formát stránky)."


def _cmd(app, arg):
    if not arg:
        app.say("Použití: /hledej dotaz")
        return
    try:
        print("\n".join("  " + l for l in _search(app, arg, "").splitlines()))
    except Exception as e:
        app.say(f"Hledání selhalo: {e}", "err")


def register(app):
    app.add_tool("search_web", _search, "vyhledá na webu a vrátí 6 výsledků (arg = dotaz); pak lze použít fetch_url")
    app.add_command("hledej", _cmd, "vyhledá na webu")
