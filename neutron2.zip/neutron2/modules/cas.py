"""Ukázkový modul – šablona pro vlastní moduly."""
from datetime import datetime

NAME = "Čas"
DESCRIPTION = "nástroj time + příkaz /cas (šablona pro vlastní moduly)"


def _time(app, arg, body):
    return datetime.now().strftime("%d.%m.%Y %H:%M:%S")


def _cmd(app, arg):
    app.say(_time(app, "", ""), "ok")


def register(app):
    app.add_tool("time", _time, "vrátí aktuální datum a čas")
    app.add_command("cas", _cmd, "ukáže aktuální čas")
