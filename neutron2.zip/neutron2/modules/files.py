import shutil
import subprocess
from datetime import datetime

NAME = "Soubory a příkazy"
DESCRIPTION = "tree, list_dir, read_file, write_file (se zálohou), find_text, run_command, /rollback"

SKIP = {".git", "node_modules", "__pycache__", ".neutron", ".venv", "venv"}


def _backup_dir(app):
    d = app.workdir / ".neutron" / "backup"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _list(app, arg, body):
    p = app.resolve(arg or ".")
    items = sorted((i for i in p.iterdir() if i.name not in SKIP), key=lambda x: (x.is_file(), x.name.lower()))
    return "\n".join(("[D] " if i.is_dir() else "    ") + i.name for i in items[:200]) or "(prázdné)"


def _tree(app, arg, body):
    root = app.resolve(arg or ".")
    lines, count = [], 0

    def walk(d, prefix, depth):
        nonlocal count
        if depth > 3 or count > 150:
            return
        items = sorted((i for i in d.iterdir() if i.name not in SKIP), key=lambda x: (x.is_file(), x.name.lower()))
        for i, it in enumerate(items):
            count += 1
            if count > 150:
                lines.append(prefix + "…")
                return
            last = i == len(items) - 1
            lines.append(prefix + ("└─ " if last else "├─ ") + it.name + ("/" if it.is_dir() else ""))
            if it.is_dir():
                walk(it, prefix + ("   " if last else "│  "), depth + 1)

    walk(root, "", 1)
    return (root.name + "/\n" + "\n".join(lines)) if lines else "(prázdné)"


def _read(app, arg, body):
    return app.resolve(arg).read_text(encoding="utf-8", errors="replace")


def _write(app, arg, body):
    p = app.resolve(arg)
    note = ""
    if p.exists():
        rel = str(p.relative_to(app.workdir.resolve())).replace("\\", "~").replace("/", "~")
        shutil.copy2(p, _backup_dir(app) / f"{datetime.now():%Y%m%d_%H%M%S}__{rel}")
        note = " (předchozí verze zálohována, /rollback)"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(body, encoding="utf-8")
    return f"Zapsáno {len(body)} znaků do {arg}{note}"


def _find(app, arg, body):
    root = app.resolve(".")
    needle, hits = arg.lower(), []
    for f in root.rglob("*"):
        if not f.is_file() or f.stat().st_size > 1_000_000 or any(x in SKIP for x in f.parts):
            continue
        try:
            for n, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
                if needle in line.lower():
                    hits.append(f"{f.relative_to(root)}:{n}: {line.strip()[:120]}")
                    if len(hits) >= 40:
                        return "\n".join(hits)
        except Exception:
            continue
    return "\n".join(hits) or "Nic nenalezeno."


def _run(app, arg, body):
    r = subprocess.run(arg, shell=True, cwd=app.workdir, capture_output=True, text=True,
                       timeout=60, encoding="utf-8", errors="replace")
    return (r.stdout + r.stderr).strip() or f"(hotovo, exit {r.returncode})"


def _rollback(app, arg):
    files = sorted(_backup_dir(app).glob("*__*"), reverse=True)
    if not files:
        app.say("Žádné zálohy v této pracovní složce.")
        return
    labels = []
    for f in files[:15]:
        stamp, _, rel = f.name.partition("__")
        labels.append(f"{stamp[:8]} {stamp[9:11]}:{stamp[11:13]}  {rel.replace('~', '/')}")
    i = app.menu("Obnovit zálohu (Esc = zpět):", labels)
    if i is None:
        return
    f = files[i]
    rel = f.name.partition("__")[2].replace("~", "/")
    shutil.copy2(f, app.workdir / rel)
    app.say(f"✔ Obnoveno: {rel}", "ok")


def register(app):
    app.add_tool("tree", _tree, "strom souborů pracovní složky (arg = podsložka, volitelné)")
    app.add_tool("list_dir", _list, "vypíše soubory ve složce (arg = relativní cesta, . = kořen)")
    app.add_tool("read_file", _read, "přečte soubor (arg = relativní cesta)")
    app.add_tool("find_text", _find, "hledá text ve všech souborech pracovní složky (arg = hledaný text)")
    app.add_tool("write_file", _write, "zapíše text z těla značky do souboru (arg = relativní cesta)", dangerous=True)
    app.add_tool("run_command", _run, "spustí příkaz v terminálu (arg = příkaz), max 60 s", dangerous=True)
    app.add_command("rollback", _rollback, "obnoví soubor ze zálohy před přepsáním AI")
