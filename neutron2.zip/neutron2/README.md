# NEUTRON 3.3

Lokální AI agent v terminálu. Offline, bez účtů, bez API klíčů.

## Rozjetí (Windows)
1. `install.bat`  (llama-cpp-python, huggingface_hub, prompt_toolkit)
2. `start.bat`
3. Při prvním startu vyber **＋ Stáhnout model** (nebo dej `.gguf` do `models/`)

## Ovládání
- **End / Esc** – zastaví generování i celý `/goal` (funguje i při zpracování promptu)
- **Tab, psaní `/`** – našeptávač příkazů; **`@`** + Tab doplňuje soubory
- **@soubor.py** v textu zprávy – obsah souboru se připojí k dotazu
- **\ na konci řádku** – víceřádková zpráva
- `/help` ukáže všechny příkazy i nástroje

## Co je nového ve 3.3 – připnutá hlavička, zarovnání všeho, víc voleb
Vše se nastavuje v `/nastaveni` (živý náhled dole):

**Připnutá hlavička** (`Hlavička a zarovnání → Připnout hlavičku nahoře`)
- Hlavička zůstane pořád nahoře a viditelná, chat se pod ní posouvá (používá scroll region terminálu).
- Styl: **kompaktní** (jeden řádek: model, ukazatel kontextu, rychlost, motiv – překresluje se živě před každou zprávou),
  **logo** (velké logo), **plný** (logo + info rámeček). Příliš vysoká hlavička se na malém okně sama zmenší.
- Při změně velikosti okna se region sám přenastaví. Vyžaduje terminál s podporou VT (Windows Terminal, moderní PowerShell).

**Zarovnání všeho** (vlevo / na střed / vpravo, každé zvlášť):
text odpovědí · hlavička (logo, tagline, rámeček) · štítky a statistiky · panely, nástroje, hlášky a oddělovače · vstupní řádek.
Položka **Zarovnat vše** nastaví všechno najednou. Seznamy, kód a tabulky zůstávají vlevo.

**Další volby**
- Vzhled: pozice vstupu, zvýraznění syntaxe, styl animace čekání (6 variant), oddělovač (přechod / čára / žádný),
  statistiky pod odpovědí, jméno nad odpovědí, info rámeček a tipy při startu.
- Model: Top-p, Top-k, penalizace opakování, seed, automatické shrnování kontextu.
- Agent: potvrzování nástrojů (jen nebezpečné / všechny / žádný), max. výstup nástroje, pípnutí po dlouhé odpovědi, autosave.
- Správa: export a načtení nastavení (`settings_export.json`).

## Co je nového ve 3.2 – spolehlivost a modely
- **`/doctor`** – ověří, že vše opravdu funguje: Python, llama-cpp-python (verze, GPU), terminál a barvy, klávesa End,
  RAM vs. velikost modelu, zápis na disk, moduly, **zkušební generování s rychlostí** a **test JSON režimu `/goal`**.
  U každého problému poradí, co udělat, a uloží zprávu do `logs/doctor.txt` (pošli ji, když budeš chtít pomoc).
- **`/models`** – správce modelů: katalog s doporučením podle tvé RAM (★), stahování s ukazatelem a rychlostí,
  **obnovení přerušeného stahování** (End = pauza), kontrola volného místa, přepínání a mazání modelů, vlastní repozitář.
- **Model se nenačte? Aplikace nespadne.** Srozumitelně vysvětlí proč (starší llama-cpp-python, málo paměti) a nabídne jiný model.
- **Chyby se zapisují do `logs/neutron.log`** (`/log` je ukáže); neočekávaná chyba už neukončí chat.
- **Qwen3: vypnutí dlouhého přemýšlení** (`/no_think`) – zapnuto ve výchozím stavu, rychlejší chat na CPU.
  Přepínač je v `/nastaveni` → Model a výkon.

### Katalog modelů
| model | velikost | RAM | poznámka |
|---|---|---|---|
| Qwen2.5 3B | ≈2.1 GB | 4+ GB | malý a rychlý, slabší čeština |
| Qwen3 4B | ≈2.5 GB | 6+ GB | dobrý univerzál |
| Qwen3 8B | ≈5 GB | 10+ GB | nejlepší poměr kvality a rychlosti |
| Qwen3 14B | ≈9 GB | 20+ GB | vysoká kvalita, na CPU pomalejší |
| Gemma 4 E4B | ≈5 GB | 8+ GB | ⚠ vyžaduje novou llama-cpp-python (starší verze model nenačtou) |

Názvy repozitářů a souborů jsou ověřené z veřejných zdrojů, velikosti jsou přibližné.

## Co je nového ve 3.1 – okno nastavení
`/nastaveni` otevře samostatné celoobrazovkové okno se stromem nastavení a živým náhledem:

| klávesa | akce |
|---|---|
| ↑ ↓ | pohyb |
| → | rozbalit kategorii / upravit položku |
| ← | zabalit kategorii (na položce zabalí její kategorii) |
| Enter | rozbalit/zabalit, upravit, přepnout, spustit |
| + / - | rychle změnit hodnotu (číslo, výběr, přepínač) |
| r | vrátit položku na výchozí |
| Esc | zavřít okno |

Kategorie: **Vzhled** (motiv, zarovnání textu vlevo/na střed/vpravo, šířka, pruh, odsazení, znak promptu, logo, animace),
**Vlastní** (jméno asistenta, tagline, systémový prompt, aliasy příkazů, pracovní složka, vlastní barvy),
**Model a výkon**, **Agent**, **Moduly**, **Správa** (obnovení výchozích hodnot).
Položky označené ⟳ vyžadují znovunačtení modelu nebo restart.

## Co je nového ve 3.0
- **/goal v JSON režimu** – každý krok agenta je omezen JSON schématem (grammar), takže i malé modely
  volají nástroje správně. Přepínač: `/set goal_mode tags` vrátí starší režim se značkami.
- **Automatické shrnování kontextu** – když se konverzace nevejde, starší část se shrne místo zahození.
- **Zálohy před přepsáním souboru** + `/rollback`.
- **Autosave konverzací**, `/load`, `/continue`.
- **Vzhled:** zvýraznění syntaxe v kódu, tabulky, citace, vodorovná čára, postup /goal, detekce GPU, boot sekvence.

## Příkazy jádra
/goal /task /theme /moduly /folder /model /nastaveni /clear /save /exit

## Moduly (složka modules/)
| soubor | co přidává |
|---|---|
| files | tree, list_dir, read_file, write_file (se zálohou), find_text, run_command, /rollback |
| web | open_url, web_search, open_app |
| fetch | fetch_url – přečte text webové stránky |
| search | search_web, /hledej – DuckDuckGo |
| git | git_status, git_diff, git_log, git_commit, /git |
| python | run_python |
| calc | calc, /calc |
| notes | dlouhodobá paměť: remember, recall, /pamet |
| todo | todo_add, todo_done, todo_list, /todo |
| sysinfo | sysinfo, /sys |
| clipboard | clipboard_get/set, /clip |
| persona | /persona – role a styl asistenta |
| export | /export – chat jako HTML v barvách motivu |
| session | autosave, /load, /continue |
| chat | /retry /undo /compact /system /stats /set /bench |
| input | přílohy @soubor |
| settings | okno nastavení (/nastaveni) |
| models | správce modelů (/models) |
| doctor | diagnostika (/doctor), /log |
| cas | ukázkový modul (šablona) |

Nástroje označené ⚡ se před spuštěním ptají na povolení.

## Vlastní modul
Soubor `modules/muj.py`:

    NAME = "Můj modul"
    DESCRIPTION = "co dělá"

    def register(app):
        app.add_tool("jmeno", lambda app, arg, body: "výsledek", "popis pro AI", dangerous=False)
        app.add_command("ahoj", lambda app, arg: app.say("Ahoj!", "ok"), "pozdraví")
        app.add_prompt_hook(lambda app: "Text přidaný do systémového promptu")
        app.add_input_filter(lambda app, text: text)      # úprava zprávy před odesláním
        app.add_after_turn(lambda app: None)               # po každé výměně
        app.add_trim_hook(lambda app, total, limit: False) # vlastní zmenšení kontextu

API objektu `app`: add_tool, add_command, add_prompt_hook, add_input_filter, add_after_turn, add_trim_hook,
ask(text), agent(kroky), say(text, "ok"|"err"|"dim"), render(markdown), menu(titulek, volby), box(titulek, řádky),
Spinner(popisek), theme, s (nastavení), stats, workdir, resolve(cesta), refresh_system(), base, messages.

## Vlastní motiv
`themes/muj.json`: {"name": "Můj", "accent": "#ff7a00", "accent2": "#ffd166", "dim": "#777777", "ok": "#7ddc7a", "err": "#ff5f5f", "think": "#666666"}
