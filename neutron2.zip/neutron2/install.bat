@echo off
chcp 65001 >nul
python -m pip install --upgrade pip
python -m pip install llama-cpp-python --prefer-binary --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu
python -m pip install huggingface_hub prompt_toolkit
pause
